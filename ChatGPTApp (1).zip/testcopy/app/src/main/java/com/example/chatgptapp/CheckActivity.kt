package com.example.chatgptapp

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket

class CheckActivity : AppCompatActivity() {
    var ip = "192.168.122.112"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_check)

        val goodButton: Button = findViewById<Button>(R.id.goodButton)
        val badButton: Button = findViewById<Button>(R.id.badButton)

        goodButton.setOnClickListener {
            var thread = NetworkThread()
            thread.start()
        }

        badButton.setOnClickListener {
            var thread2 = NetworkThread2()
            thread2.start()
        }


    }

    inner class NetworkThread : Thread(){
        override fun run(){
            try{
                var socket = Socket(ip,3001)
                var input = socket.getInputStream()
                var dis = DataInputStream(input)

                var output = socket.getOutputStream()
                var dos = DataOutputStream(output)
                //dos.writeInt(1)
                dos.writeBoolean(true)
                //dos.writeUTF("1")
                socket.close()

            }catch(e:Exception){
                e.printStackTrace()
            }
        }
    }

    inner class NetworkThread2 : Thread(){
        override fun run(){
            try{
                var socket = Socket(ip,3001)
                var input = socket.getInputStream()
                var dis = DataInputStream(input)

                var output = socket.getOutputStream()
                var dos = DataOutputStream(output)
                //dos.writeBoolean(false)
                dos.writeInt(100)
                //dos.writeUTF("test")
                socket.close()

            }catch(e:Exception){
                e.printStackTrace()
            }
        }
    }

}

