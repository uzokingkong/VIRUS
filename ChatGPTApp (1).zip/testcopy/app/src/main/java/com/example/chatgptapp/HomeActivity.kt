package com.example.chatgptapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        var chatButton: ImageButton = findViewById<ImageButton>(R.id.chatButton)
        var checkButton: Button = findViewById<Button>(R.id.checkButton)
        var simributton:ImageButton = findViewById<ImageButton>(R.id.simritest)

        chatButton.setOnClickListener {
            var intent = Intent(this, ChatActivity::class.java)
            startActivity(intent)
        }

        checkButton.setOnClickListener {
            var intent = Intent(this, CheckActivity::class.java)
            startActivity(intent)
        }
        simributton.setOnClickListener {
            var intent = Intent(this, SimriActivity::class.java)
            startActivity(intent)
        }

    }
}