package com.example.chatgptapp

object API_KEY {
    const val MY_API_KEY = "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"
}