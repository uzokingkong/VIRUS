package com.example.chatgptapp
import android.os.Bundle
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class SimriActivity : AppCompatActivity() {
    private val questions = listOf(
        q1, q2, q3, q4, q5, q6, q7, q8, q9, q10,
        q11, q12, q13, q14, q15, q16, q17, q18, q19, q20,
        q21, q22, q23, q24, q25, q26, q27, q28, q29, q30,
        q31, q32, q33, q34, q35, q36, q37, q38, q39, q40,
        q41, q42, q43, q44, q45, q46, q47, q48, q49, q50,
        q51, q52, q53, q54, q55, q56, q57, q58, q59, q60
    )
    private var currentQuestionIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        showQuestionAndOptions()

        nextButton.setOnClickListener {
            if (currentQuestionIndex < questions.size - 1) {
                currentQuestionIndex++
                showQuestionAndOptions()
            } else {
                Toast.makeText(this, "마지막 문제입니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showQuestionAndOptions() {
        val currentQuestion = questions[currentQuestionIndex]
        questionTextView.text = currentQuestion.statement

        answerOption0.text = "예"
        answerOption1.text = "보통"
        answerOption2.text = "아니오"

        // Here you can customize the options based on the currentQuestion or any other logic if needed
    }
}
