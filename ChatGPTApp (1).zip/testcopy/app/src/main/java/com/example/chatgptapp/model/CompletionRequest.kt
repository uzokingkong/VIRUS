package com.example.chatgptapp.model

import org.json.JSONArray

data class CompletionRequest(
    val model: String,
    val messages: JSONArray
)