package com.example.chatgptapp

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.chatgptapp.API_KEY.MY_API_KEY
import com.example.chatgptapp.data.ApiClient

import com.example.chatgptapp.model.CompletionRequest
import com.example.chatgptapp.model.CompletionResponse
import com.example.chatgptapp.model.Message
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Response
import java.io.IOException
import java.net.SocketTimeoutException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class ChatGptViewModel : ViewModel(){

    private val _messageList = MutableLiveData<MutableList<Message>>()

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()


    val messageList : LiveData<MutableList<Message>> get() = _messageList

    init {
        _messageList.value = mutableListOf()
    }

    fun addToChat(message : String , sentBy : String , timestamp : String){
        val currentList = _messageList.value ?: mutableListOf()
        currentList.add(Message(message,sentBy,timestamp))
        _messageList.postValue(currentList)
    }


    private fun addResponse(response : String){
        _messageList.value?.removeAt(_messageList.value?.size?.minus(1) ?: 0)
        addToChat(response,Message.SENT_BY_BOT,getCurrentTimestamp())
    }

    fun callApi(question : String){
        addToChat("입력중...",Message.SENT_BY_BOT,getCurrentTimestamp())


        val messageList = JSONArray()
        val baseAi = JSONObject()
        val userMsg = JSONObject()

        try {
            //AI 속성설정
            //baseAi.put("role", "user")
            baseAi.put("role", "system")
            baseAi.put("content", "너는 친절한 나의 심리상담가야. 한국어 친근한 반말로 대답해줘")
            //유저 메세지
            userMsg.put("role", "user")
            userMsg.put("content", question)
            //array로 담아서 한번에 보낸다
            messageList.put(baseAi)
            messageList.put(userMsg)
        } catch (e: JSONException) {
            throw RuntimeException(e)
        }

        val jsonObject = JSONObject()
        try {
            //모델명 변경
            jsonObject.put("model", "gpt-3.5-turbo")
            jsonObject.put("messages", messageList)

        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val body: RequestBody = jsonObject.toString().toRequestBody("application/json".toMediaTypeOrNull())

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Content-Type", "application/json")
            .addHeader("Authorization", "Bearer $MY_API_KEY")
            //.post(requestBody.toRequestBody("application/json".toMediaTypeOrNull()))
            .post(body)
            .build()


        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("error","API failed",e)
            }

            override fun onResponse(call: Call, response: okhttp3.Response) {
                val body=response.body?.string()
                if (body != null) {
                    Log.v("data",body)
                }
                else{
                    Log.v("data","empty")
                }
                val jsonObject= JSONObject(body)
                val jsonArray: JSONArray =jsonObject.getJSONArray("choices")
                val textResult=jsonArray.getJSONObject(0).getJSONObject("message").getString("content")
                addResponse(textResult)
            }
        })
    }



    private suspend fun handleApiResponse(response: Response<CompletionResponse>) {
        withContext(Dispatchers.Main){
            if (response.isSuccessful){
                response.body()?.let { completionResponse ->
                    //val messageResult = completionResponse.choices.firstOrNull()?.message
                    //al result=messageResult?.getString("content")
                    val midresult = completionResponse.choices.firstOrNull()?.message
                    val result = midresult?.getString("content")
                    if (result != null) {
                        addResponse(result.trim())
                    } else {
                        addResponse("No choices found")
                    }

                }
            }else{
                addResponse("Failed to get response ${response.errorBody()}")
            }
        }

    }

    fun getCurrentTimestamp(): String {
       return SimpleDateFormat("hh mm a", Locale.getDefault()).format(Date())
    }


}