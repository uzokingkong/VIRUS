package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val emailedit: EditText = findViewById(R.id.emailEditText)
        val passworddit: EditText = findViewById(R.id.passwordEditText)
        val loginbutton: Button = findViewById(R.id.loginButton)
        val singupbutton: Button = findViewById(R.id.signupButton)
        val Textedit = emailedit.text
        val passwordedit = passworddit.text
        loginbutton.setOnClickListener {
            Toast.makeText(this, Textedit, Toast.LENGTH_SHORT).show()


        }
        singupbutton.setOnClickListener {
            Toast.makeText(this, passwordedit, Toast.LENGTH_SHORT).show()
        }
    }6
    private fun login(email:String, password:String) {



    }

}